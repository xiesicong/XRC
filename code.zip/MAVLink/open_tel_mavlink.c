#include "open_tel_mavlink.h"//??:????  qq:624668529

#include "mavlink_usart_fifo.h"
#include "define.h"
#include "stdint.h"
#include "delay.h"
u8 requst_sys_id=0,requst_commond_id=0,requst_stream_id=0;
u8 flag_guided_target_reached=1;
u8 is_enable_connect=0;
mavlink_system_t                          mavlink_system;
extern u8 tele_flag;
extern char temp_display[50];
int received=0;

typedef uint8_t bool;

int8_t control_mode = STABILIZE;

mavlink_channel_t          						 		chan;
mavlink_heartbeat_t        						 		heartbeat;
mavlink_attitude_t        					 	 		attitude;
mavlink_mission_ack_t  								 		mission_ack;
mavlink_mission_item_t   							 		mission_item;
mavlink_mission_item_t 								 		guided_target;
mavlink_mission_count_t   						 		mission_count;
mavlink_mission_request_t  						 		mission_request;
mavlink_optical_flow_t   						   		opt_flow;
mavlink_rc_channels_raw_t   					 		rc_input;
mavlink_global_position_int_t					 		position;
mavlink_set_mode_t         						 		msg_set_mode;
mavlink_mission_item_reached_t				 		my_mission_item_reached;
mavlink_gps_raw_int_t       					 		GPS_raw;
mavlink_set_mode_t										 		send_set_mode;
mavlink_command_long_t								 		rx_cmd,tx_cmd;
mavlink_request_data_stream_t					 		tx_request_data_stream;
mavlink_vfr_hud_t											 		rx_vfr_hud;
mavlink_rc_channels_override_t         		rx_rc_override,tx_rc_override;
mavlink_attitude_setpoint_external_t	 		tx_attitude_target;
mavlink_battery_status_t               		battery_status;
mavlink_power_status_t                 		power_status;
mavlink_statustext_t									 		rx_text,tx_text;
mavlink_sys_status_t                   		rx_sys_status;
mavlink_radio_status_t        				 		radio_status; 
mavlink_rc_channels_t                  		rc;
mavlink_servo_output_raw_t             		servo_raw;
mavlink_mission_current_t  				 		    mission_current_no;
mavlink_mission_request_list_t            mission_request_list;     
mavlink_mission_request_t                 mission_request_flag;

mavlink_system_time_t                     sys_time;
mavlink_raw_imu_t                         raw_imu;
mavlink_scaled_pressure_t                 scaled_pressure;
mavlink_mission_current_t                 current_mission;
mavlink_nav_controller_output_t 					nav_controller_output;
mavlink_scaled_imu2_t											scaled_imu2;
mavlink_param_value_t											param_value;
mavlink_rc_channels_scaled_t              rc_channel_scaled;


u8 data_stream_request_rate=0;
u8 try_send_mission_ack;
u8 mission_return_flag=0;
u8 mission_return_count=0;
uint8_t buf[100];
u16 temp=1500;
////End Add By BigW
//// -*- tab-width: 4; Mode: C++; c-basic-offset: 4; indent-tabs-mode: nil -*-
// this costs us 51 bytes, but means that low priority
// messages don't block the CPU
static mavlink_statustext_t pending_status;
// true when we have received at least 1 MAVLink packet
//static bool mavlink_active;
// check if a message will fit in the payload space available
#define CHECK_PAYLOAD_SIZE(id) if (payload_space < MAVLINK_MSG_ID_ ## id ## _LEN) return false
void handleMessage(mavlink_message_t* msg);
/*
 *  !!NOTE!!
 *
 *  the use of NOINLINE separate functions for each message type avoids
 *  a compiler bug in gcc that would cause it to use far more stack
 *  space than is needed. Without the NOINLINE we use the sum of the
 *  stack needed for each message type. Please be careful to follow the
 *  pattern below when adding any new messages
 */
static NOINLINE void send_heartbeat(mavlink_channel_t chan)
{
    uint8_t base_mode = MAV_MODE_FLAG_CUSTOM_MODE_ENABLED;
    uint8_t system_status = MAV_STATE_ACTIVE;
    uint32_t custom_mode = control_mode;
    // work out the base_mode. This value is not very useful
    // for APM, but we calculate it as best we can so a generic
    // MAVLink enabled ground station can work out something about
    // what the MAV is up to. The actual bit values are highly
    // ambiguous for most of the APM flight modes. In practice, you
    // only get useful information from the custom_mode, which maps to
    // the APM flight mode and has a well defined meaning in the
    // ArduPlane documentation
    base_mode = MAV_MODE_FLAG_STABILIZE_ENABLED;
    switch (control_mode) {
    case AUTO:
    case RTL:
    case LOITER:
    case GUIDED:
    case CIRCLE:
        base_mode |= MAV_MODE_FLAG_GUIDED_ENABLED;
        // note that MAV_MODE_FLAG_AUTO_ENABLED does not match what
        // APM does in any mode, as that is defined as "system finds its own goal
        // positions", which APM does not currently do
        break;
    }
    // all modes except INITIALISING have some form of manual
    // override if stick mixing is enabled
    base_mode |= MAV_MODE_FLAG_MANUAL_INPUT_ENABLED;
#if HIL_MODE != HIL_MODE_DISABLED
    base_mode |= MAV_MODE_FLAG_HIL_ENABLED;
#endif
    // we are armed if we are not initialising
    if (0){//motors.armed()) {
        base_mode |= MAV_MODE_FLAG_SAFETY_ARMED;
    }
    // indicate we have set a custom mode
    base_mode |= MAV_MODE_FLAG_CUSTOM_MODE_ENABLED;
    mavlink_msg_heartbeat_send(
        chan,
        MAV_TYPE_QUADROTOR,
        MAV_AUTOPILOT_ARDUPILOTMEGA,
        base_mode,
        custom_mode,
        system_status);
}
static NOINLINE void send_attitude(mavlink_channel_t chan)
{
    mavlink_msg_attitude_send(
        chan,
        ++buf[1],//millis(),
        ++buf[2]/57.3,//ahrs.roll,
        ++buf[3]/57.3,//ahrs.pitch,
        ++buf[4]/57.3,//ahrs.yaw,
        ++buf[5],//omega.x,
        ++buf[6],//omega.y,
        ++buf[7]);//omega.z);
}
 
static void NOINLINE send_location(mavlink_channel_t chan)
{
    //Matrix3f rot = ahrs.get_dcm_matrix(); // neglecting angle of attack for now
    mavlink_msg_global_position_int_send(
        chan,
        1,//millis(),
        2,//current_loc.lat,                // in 1E7 degrees
        3,//current_loc.lng,                // in 1E7 degrees
        40,//g_gps->altitude * 10,             // millimeters above sea level
        5,//(current_loc.alt - home.alt) * 10,           // millimeters above ground
        6,//g_gps->ground_speed * rot.a.x,  // X speed cm/s
        7,//g_gps->ground_speed * rot.b.x,  // Y speed cm/s
        8,//g_gps->ground_speed * rot.c.x,
        9);//g_gps->ground_course);          // course in 1/100 degree
}
static void NOINLINE send_rc_in(mavlink_channel_t chan)
{
    //Vector3f omega_I = ahrs.get_gyro_drift();
	
    mavlink_msg_rc_channels_raw_send(
        chan,
        0,//omega_I.x,
				buf[1],
        1100,//omega_I.y,
        1100,//omega_I.z,
        ++temp,
        1100,
        1100,//ahrs.get_error_rp(),
        1100,
				1100,
				1100,
				150);//ahrs.get_error_yaw());
}

static void NOINLINE send_gps(mavlink_channel_t chan)
{
    //Vector3f omega_I = ahrs.get_gyro_drift();
	
    mavlink_msg_gps_raw_int_send(
        chan,
        0,//omega_I.x,
				3,
				348131755,
				1135246868,
        100000,//omega_I.y,
        10,//omega_I.z,
        10,
        UINT16_MAX,
        UINT16_MAX,//ahrs.get_error_rp(),
        80);//ahrs.get_error_yaw());
}


static void NOINLINE send_requst(mavlink_channel_t chan)
{
    //Vector3f omega_I = ahrs.get_gyro_drift();
	
    mavlink_msg_request_data_stream_send(
        chan,
        mavlink_system.sysid,//requst_sys_id,//omega_I.x,
				mavlink_system.compid,//requst_commond_id,
				tx_request_data_stream.req_stream_id,
				tx_request_data_stream.req_message_rate,
        tx_request_data_stream.start_stop      
        );//ahrs.get_error_yaw());
}

static void NOINLINE send_mission_item_home(mavlink_channel_t chan)
{
	mavlink_msg_mission_item_send(
		chan,
		mavlink_system.sysid,
		mavlink_system.compid,
		0,//�������
		MAV_FRAME_GLOBAL,//����ϵ������վ����ʱֻ��
		16,//MAV_CMD_NAV_WAYPOINT
		0,//����Ϊ��ǰ����
		0,//�Զ���ʼ�¸�����
		0.0,//פ��ʱ�䣬��
	  0.0,//����뾶
		0.0,//˳ʱ��
		0.0,//
		guided_target.x,//	����		
		guided_target.y,//γ��
		guided_target.z	//�߶�
		);
}

static void NOINLINE send_mission_item_waypoint(mavlink_channel_t chan)
{
	mavlink_msg_mission_item_send(
		chan,
		mavlink_system.sysid,
		mavlink_system.compid,
		guided_target.seq,//�������
		MAV_FRAME_GLOBAL_RELATIVE_ALT,
	//����ϵ������վ����ʱֻ��home����0(MAV_FRAME_GLOBAL)
	//���ຽ���Ϊ3(MAV_FRAME_GLOBAL_RELATIVE_ALT)	                           
		guided_target.command,//MAV_CMD_NAV_WAYPOINT
		guided_target.current,//��Ϊ��ǰ���� current
		guided_target.autocontinue,//���Զ���ʼ�¸�����
		0,//פ��ʱ�䣬��
	  0,//����뾶
		0,//˳ʱ��
		0,//ָ���趨
	//����վ����ʱ��ͨ��������ĸ�������Ϊ0
		guided_target.x,//	γ��		
		guided_target.y,//  ����
		guided_target.z	//�߶�
		);
}

static void NOINLINE send_mission_count(mavlink_channel_t chan)
{
	mavlink_msg_mission_count_send(
			chan,
			mavlink_system.sysid,
			mavlink_system.compid,
			mission_count.count
	);
}

static void NOINLINE send_mission_ack(mavlink_channel_t chan)
{
	mavlink_msg_mission_ack_send(
		chan,
		mavlink_system.sysid,
		mavlink_system.compid,
		0
	);
}

static void NOINLINE set_mode(mavlink_channel_t chan)
{
	mavlink_msg_set_mode_send(
	chan,
	mavlink_system.sysid,
	send_set_mode.base_mode,
	send_set_mode.custom_mode
	);
}

static void NOINLINE send_cmd(mavlink_channel_t chan)
{
	mavlink_msg_command_long_send(
	chan,
	mavlink_system.sysid,
	mavlink_system.compid,
	tx_cmd.command,
	tx_cmd.confirmation,
	tx_cmd.param1,
	tx_cmd.param2,
	tx_cmd.param3,
	tx_cmd.param4,
	tx_cmd.param5,
	tx_cmd.param6,
	tx_cmd.param7
	);
}

static void NOINLINE send_rc_override(mavlink_channel_t chan)
{
	mavlink_msg_rc_channels_override_send(
	chan,
	0,
	0,
	tx_rc_override.chan1_raw,
	tx_rc_override.chan2_raw,
	tx_rc_override.chan3_raw,
	tx_rc_override.chan4_raw,
	tx_rc_override.chan5_raw,
	tx_rc_override.chan6_raw,
	tx_rc_override.chan7_raw,
	tx_rc_override.chan8_raw
	);
}

static void NOINLINE send_attitude_targrt(mavlink_channel_t chan)
{
mavlink_msg_attitude_setpoint_external_send(
		chan,
		tx_attitude_target.time_boot_ms,
		mavlink_system.sysid,
		mavlink_system.compid,
		tx_attitude_target.type_mask,
		tx_attitude_target.q,
		tx_attitude_target.body_roll_rate,
		tx_attitude_target.body_pitch_rate,
		tx_attitude_target.body_yaw_rate,		
		tx_attitude_target.thrust

	);
}
static void NOINLINE send_mission_request_list(mavlink_channel_t chan)////////////////返回任务列表
{
	mavlink_msg_mission_request_list_send(chan,mission_request_list.target_component,mission_request_list.target_system);
}

static void NOINLINE send_mission_request(mavlink_channel_t chan)////////////////返回任务列表
{
	mavlink_msg_mission_request_send(chan,mission_request.target_system,mission_request.target_component,mission_request.seq);
}

static void NOINLINE send_mission_current(mavlink_channel_t chan)//////////////////////////执行指定序号的任务
{
	mavlink_msg_mission_current_send(chan,mission_current_no.seq);
}
static void NOINLINE send_statustext(mavlink_channel_t chan)
{
		mavlink_msg_statustext_send(chan,tx_text.severity,tx_text.text);
}
// are we still delaying telemetry to try to avoid Xbee bricking?
static bool telemetry_delayed(mavlink_channel_t chan)
{
    return false;
}
// try to send a message, return false if it won't fit in the serial tx buffer
static bool mavlink_try_send_message(mavlink_channel_t chan, enum ap_message id, uint16_t packet_drops)
{
    int16_t payload_space = serial_free();
    if (telemetry_delayed(chan))
		{
        return false;
    }
    switch(id) 
		{
      case MSG_HEARTBEAT:
        CHECK_PAYLOAD_SIZE(HEARTBEAT);
        send_heartbeat(chan);
        break;
      case MSG_ATTITUDE:
        CHECK_PAYLOAD_SIZE(ATTITUDE);
        send_attitude(chan);
        break;
      case MSG_LOCATION:
        CHECK_PAYLOAD_SIZE(GLOBAL_POSITION_INT);
        send_location(chan);
        break;
      case MSG_RADIO_IN:
        CHECK_PAYLOAD_SIZE(RC_CHANNELS_RAW);
        send_rc_in(chan);
        break;
      case MSG_STATUSTEXT:
        CHECK_PAYLOAD_SIZE(STATUSTEXT);
        send_statustext(chan);
				break;
			case MSG_GPS_RAW:
				CHECK_PAYLOAD_SIZE(GPS_RAW_INT);
				send_gps(chan);	
				break;
			case MSG_ID_REQUEST_DATA_STREAM:
				CHECK_PAYLOAD_SIZE(REQUEST_DATA_STREAM);
				send_requst(chan);
				break;
			case MSG_ID_MISSION_CURRENT:
				CHECK_PAYLOAD_SIZE(MISSION_CURRENT);/////////////////////////////////////////////////////////////////
				send_mission_current(chan);
				break;
			case MSG_ID_MISSION_ITEM_HOME:
				CHECK_PAYLOAD_SIZE(MISSION_ITEM);
				send_mission_item_home(chan);
				break;
			case MSG_ID_MISSION_ITEM_WAYPOINT:
				CHECK_PAYLOAD_SIZE(MISSION_ITEM);
				send_mission_item_waypoint(chan);
				break;
			case MSG_ID_MISSION_COUNT:
				CHECK_PAYLOAD_SIZE(MISSION_COUNT);
				send_mission_count(chan);
				break;
			case MSG_ID_MISSION_REQUEST_LIST:
				CHECK_PAYLOAD_SIZE(MISSION_REQUEST_LIST);///////////////////////////////////////////获取任务清单
				send_mission_request_list(chan);
				break;
			case MSG_ID_MISSION_REQUEST:
				CHECK_PAYLOAD_SIZE(MISSION_REQUEST);
				send_mission_request(chan);
				break;
			case MSG_ID_MISSION_ACK:
				CHECK_PAYLOAD_SIZE(MISSION_ACK);
				send_mission_ack(chan);
				break;
			case MSG_ID_SET_MODE:
				CHECK_PAYLOAD_SIZE(SET_MODE);
				set_mode(chan);
				break;
			case MSG_ID_COMMAND_LONG:
				CHECK_PAYLOAD_SIZE(COMMAND_LONG);
				send_cmd(chan);
				break;
			case MSG_ID_RC_CHANNELS_OVERRIDE:
				CHECK_PAYLOAD_SIZE(RC_CHANNELS_OVERRIDE);
				send_rc_override(chan);
				break;
			case MSG_ID_ATTITUDE_SETPOINT_EXTERNAL:
				CHECK_PAYLOAD_SIZE(ATTITUDE_SETPOINT_EXTERNAL);
				send_attitude_targrt(chan);
				break;			
			default:
				break;
    }
    return true;
}
#define MAX_DEFERRED_MESSAGES MSG_RETRY_DEFERRED
static struct mavlink_queue {
    enum ap_message deferred_messages[MAX_DEFERRED_MESSAGES];
    uint8_t next_deferred_message;
    uint8_t num_deferred_messages;
} mavlink_queue[2];
// send a message using mavlink
void mavlink_send_message(mavlink_channel_t chan, enum ap_message id, uint16_t packet_drops)
{
    uint8_t i, nextid;
    struct mavlink_queue *q = &mavlink_queue[(uint8_t)chan];
    while (q->num_deferred_messages != 0) 
		{
				if (!mavlink_try_send_message(chan,q->deferred_messages[q->next_deferred_message], packet_drops)) 
				{
            break;
        }
        q->next_deferred_message++;
        if (q->next_deferred_message == MAX_DEFERRED_MESSAGES) 
				{
            q->next_deferred_message = 0;
        }
        q->num_deferred_messages--;
    }
    if (id == MSG_RETRY_DEFERRED) 
		{
        return;
    }
    for (i=0, nextid = q->next_deferred_message; i < q->num_deferred_messages; i++) 
		{
        if (q->deferred_messages[nextid] == id) 
				{
            return;
        }
        nextid++;
        if (nextid == MAX_DEFERRED_MESSAGES) 
				{
            nextid = 0;
        }
    }
    if (q->num_deferred_messages != 0 ||!mavlink_try_send_message(chan, id, packet_drops))
		{
        if (q->num_deferred_messages == MAX_DEFERRED_MESSAGES) 
				{          
            return;// the defer buffer is full, discard
        }
        nextid = q->next_deferred_message + q->num_deferred_messages;
        if (nextid >= MAX_DEFERRED_MESSAGES) 
				{
            nextid -= MAX_DEFERRED_MESSAGES;
        }
        q->deferred_messages[nextid] = id;
        q->num_deferred_messages++;
    }
}
void mavlink_send_text(mavlink_channel_t chan, enum gcs_severity severity, char *str)
{
    if (telemetry_delayed(chan)) {
        return;
    }
    if (severity == SEVERITY_LOW) {
        pending_status.severity = (uint8_t)severity;
        mav_array_memcpy((char *)pending_status.text, str, sizeof(pending_status.text));
        mavlink_send_message(chan, MSG_STATUSTEXT, 0);
    } 
		else 
		{
        mavlink_msg_statustext_send(
        chan,
        severity,
        str);
    }
}
void update(void)
{
    mavlink_message_t msg;
    mavlink_status_t status;
    status.packet_rx_drop_count = 0;	
    while(serial_available())
    {
		
				uint8_t c = serial_read_ch(); 
				if(mavlink_parse_char(chan, c, &msg, &status)) 
				{
						handleMessage(&msg);
						tele_flag=3;
				}			
    }
}
////3     0  1  2  3  0  0  00000000000000000000
#if MSGID
extern u8 msgid[50];
#endif
void handleMessage(mavlink_message_t* msg)
{
	
#if MSGID	
	u8 i=1;
	for(i=1;i<50;i++)
	{
		if(msg->msgid==msgid[i])break;
		else if(msgid[i]==0) 
		{
			//if(msgid[i]
			msgid[i]=msg->msgid;		
			break;
		}
	}
#endif
    switch (msg->msgid)
		{			
        case  MAVLINK_MSG_ID_HEARTBEAT:{                //心跳包							#0  xxxxxxxxxxxxx										
					mavlink_msg_heartbeat_decode(msg, &heartbeat); 
          break;
				}	
				case MAVLINK_MSG_ID_SYS_STATUS:{               //系统状态							#1 xxxxxxxxxxxxxx
					mavlink_msg_sys_status_decode(msg,&rx_sys_status);				
					break;			
				}	
				case MAVLINK_MSG_ID_SYSTEM_TIME:{
					mavlink_msg_system_time_decode(msg,&sys_time);//系统时间  					#2 xxxxxxxxxxxxxxxx
					break;
				}	
				case MAVLINK_MSG_ID_PARAM_VALUE:{								//参数值							#22xxxxxxxxxxxxxxxx
					mavlink_msg_param_value_decode(msg,&param_value);
					break;			
				}
				case MAVLINK_MSG_ID_GPS_RAW_INT:{              //RAW的格式的GPS数据		#24xxxxxxxxxxxxxxxx
					mavlink_msg_gps_raw_int_decode(msg,&GPS_raw);			
					break;
				}
				case MAVLINK_MSG_ID_RAW_IMU:{									//原始的姿态传感器信息  #27xxxxxxxxxxxxx
					mavlink_msg_raw_imu_decode(msg,&raw_imu);
					break;		
				}
				case MAVLINK_MSG_ID_SCALED_PRESSURE:{         //处理后的气压计信息    #29xxxxxxxxxxxxx
					mavlink_msg_scaled_pressure_decode(msg,&scaled_pressure);
					break;		
				}
				case MAVLINK_MSG_ID_ATTITUDE:{                  //姿态   						  #30  xxxxxxxxxxxx
					mavlink_msg_attitude_decode(msg, &attitude);
				  break;
				}
				case MAVLINK_MSG_ID_GLOBAL_POSITION_INT:{     //GPS整型数据  					#33xxxxxxxxxxxxxxxxx
					 mavlink_msg_global_position_int_decode(msg, &position);
					 break;
				}
				case MAVLINK_MSG_ID_RC_CHANNELS_SCALED:{     //RC_CHANNEL_SCALED整型数据  					#34xxxxxxxxxxxxxxxxx
					 mavlink_msg_rc_channels_scaled_decode(msg, &rc_channel_scaled);
					 break;
				}
				case MAVLINK_MSG_ID_RC_CHANNELS_RAW:{         //遥控通道数据					#35xxxxxxxxxxxxxxx
					 mavlink_msg_rc_channels_raw_decode(msg, &rc_input); 		
					 break;
				}				
				case MAVLINK_MSG_ID_SERVO_OUTPUT_RAW:{         //舵机RAW值 						#36xxxxxxxxxxxxxxxxx
					mavlink_msg_servo_output_raw_decode(msg,&servo_raw);
					break;
				}
				case MAVLINK_MSG_ID_MISSION_ITEM:           //航点任务详细数据        #39      
				{            
					mavlink_msg_mission_item_decode(msg,&mission_item);
					if(mission_request.seq)
					{
						mission_position[mission_request.seq][0]=mission_item.x;
						mission_position[mission_request.seq][1]=mission_item.y;
						mission_position[mission_request.seq][2]=mission_item.z;
					}				
					mission_request.seq++;
					mission_receive_waypoint_flag=1;
					if(mission_request.seq<mission_count.count)
					{							
						mavlink_send_message(chan,MSG_ID_MISSION_REQUEST,0);
						mission_return_count=0;
					}
					else
					{
						mission_return_flag=0;				
						mavlink_send_message(chan,MSG_ID_MISSION_ACK,0);				
					}						
					break;
				}
				case MAVLINK_MSG_ID_MISSION_REQUEST:{          //任务请求序号					#40
					mavlink_msg_mission_request_decode(msg,&mission_request);
					mission_flag=1;
					break;
				}
				case MAVLINK_MSG_ID_MISSION_CURRENT:{					//当前任务序号					#42
					mavlink_msg_mission_current_decode(msg,&current_mission);
					break;			
				}
				case MAVLINK_MSG_ID_MISSION_COUNT:{            //任务计数							#44
					mavlink_msg_mission_count_decode(msg,&mission_count);	
					mission_request.seq=0;
					mavlink_send_message(chan,MSG_ID_MISSION_REQUEST,0);
					mission_return_flag=1;				
					break;
				}
				case MAVLINK_MSG_ID_MISSION_ITEM_REACHED:{     //任务到达序号         #46
					mavlink_msg_mission_item_reached_decode(msg,&my_mission_item_reached);
					flag_guided_target_reached=1;
					break;
				}
				case MAVLINK_MSG_ID_MISSION_ACK:{             //任务回应 							#47
						mavlink_msg_mission_ack_decode(msg,&mission_ack);
					break;
				}										
				case MAVLINK_MSG_ID_NAV_CONTROLLER_OUTPUT:{		//											#62	
					mavlink_msg_nav_controller_output_decode(msg,&nav_controller_output);
					break;
				}
				case MAVLINK_MSG_ID_RC_CHANNELS:{              //16通道遥控数据				#65	
					mavlink_msg_rc_channels_decode(msg,&rc);				
					break;	
				}	
				case MAVLINK_MSG_ID_VFR_HUD:{                  //HUD数据              #74
					mavlink_msg_vfr_hud_decode(msg,&rx_vfr_hud);	
					break;
				}				
				case MAVLINK_MSG_ID_COMMAND_LONG:{             //命令                 #77
					mavlink_msg_command_long_decode(msg,&rx_cmd);
					break;
				}
				case MAVLINK_MSG_ID_SCALED_IMU2:{					//处理后的IMU2传感器信息		#116
					mavlink_msg_scaled_imu2_decode(msg,&scaled_imu2);
					break;
				}
				case MAVLINK_MSG_ID_POWER_STATUS:{             //电源状态							#125		
					mavlink_msg_power_status_decode(msg,&power_status);		
					break;
				}
				case MAVLINK_MSG_ID_STATUSTEXT:{               //系统状态描述					#253
					mavlink_msg_statustext_decode(msg,&rx_text);
					text_flag=1;
					break;
				}								
				case MAVLINK_MSG_ID_OPTICAL_FLOW:{             //光流定位数据         #100
					mavlink_msg_optical_flow_decode(msg,&opt_flow);				
					break;
				}			
				case MAVLINK_MSG_ID_SET_MODE:{                 //设置模式             #11
					mavlink_msg_set_mode_decode(msg,&msg_set_mode);
					control_mode=msg_set_mode.custom_mode;
					break;
				}			
				case MAVLINK_MSG_ID_BATTERY_STATUS:{           //电池状态							#
					mavlink_msg_battery_status_decode(msg,&battery_status);		
					break;
				}				
				case MAVLINK_MSG_ID_RADIO_STATUS:{             //电台状态							#
					mavlink_msg_radio_status_decode(msg,&radio_status);				
					break;		
				}				
				default: break;				
    } 		
		/*	
		{
			char temp[5];
		sprintf(temp,"%d  ",msg->msgid);
			u3_printf(temp);	
		}	
		
		*/
		if((mission_return_count>20)&&mission_return_flag)
			{
				if(mission_request.seq<mission_count.count)
					{		
						mavlink_send_message(chan,MSG_ID_MISSION_REQUEST,0);
					}
				mission_return_count=0;
			}		
			if(mission_return_flag)mission_return_count++;
	/*
	#0   HEARTBEAT;						  
	#1	 SYS_STATUS						 
	#2	 SYS_TIME							 
	#22  PARAM_VALUE						
	#24	 GPS_RAW_INT						
	#27	 RAW_INT								
	#29  SCALED_PRESSURE				
	#30  ATTITUDE
	#33  GLOBAL_POSITION_INT
	#35  RC_CHANNELS_RAW
	#36  SERVO_OUTPUT_RAW
	#39  MISSION_ITEM
	#40  MISSION_REQUEST
	#42  MISSION_CURRENT		
	#44  MISSION_COUNT
	#47  MISSION_ACK
	#62  NAV_CONTROLLER_OUTPUT		
	#65  RC_CHANNELS	
	#74  VFR_HUD	
	#77  COMMAND_ACK
	#116 SCALED_IMU2		
	#125 POWER_SATTUS		
	#253 STATUSTEXT			
	*/			
} 
