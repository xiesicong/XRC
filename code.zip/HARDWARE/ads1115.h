#ifndef __ADS_H
#define __ADS_H
#include "sys.h"
void ADS_Init(void);

u16 Get_ADS (u8 ch);





#endif


