#ifndef _EOS_PLUGIN_SHELL_H_
#define _EOS_PLUGIN_SHELL_H_
#include "delay.h"
#include "string.h"

#define os_shell_printf(fmt, ...) { os_lock(); printf( fmt, ##__VA_ARGS__); os_unlock();}//OS�ṩ�Ĵ�ӡ�������
#define shell_rx_buff_len     50
#define shell_rx_dig_buff_len 10
typedef struct
{
  char rx_buff[shell_rx_buff_len];
	os_u32 rx_dig_buff[shell_rx_dig_buff_len];
	os_u32 rx_counter;
	os_bool bool_rx_ok;
	os_bool bool_enter_sys;
}OS_SHELL_CMD;
extern OS_SHELL_CMD os_shell_cmd;

typedef struct
{	
	os_u32 runtime_year;
	os_u32 shutdowntime_year;
	
	os_u16 runtime_ms;
	
	os_u8  runtime_second;
	os_u8  runtime_minute;
	os_u8  runtime_hour;
	os_u8  runtime_day;
	os_u8  runtime_mouth;
	
  os_u8  shutdowntime_second;
	os_u8  shutdowntime_minute;
	os_u8  shutdowntime_hour;
	os_u8  shutdowntime_day;
	os_u8  shutdowntime_mouth;
}OS_SHELL_TIME;
extern OS_SHELL_TIME os_shell_time;

typedef struct
{	
	os_stk     *stk_ptr[OS_APP_MAX];
	os_u32     stk_size_used[OS_APP_MAX];
	os_u32     stk_size_free[OS_APP_MAX];
	os_u32     app_cpu_occrate_counter[OS_APP_MAX];
	os_u16     cpu_occrate_per1000;
	os_u16     cpu_occrate_per1000_max;
	os_u16     app_cpu_occrate_per1000[OS_APP_MAX];
	os_u8      os_state;
}OS_SHELL_DATA;
extern OS_SHELL_DATA os_shell_data;



void os_shell_input(os_u8 rx_byte);//���ڽӿں���(���ڴ��ڽ����ж���)
void user_cmd_add(void);
void os_shell_handle_process(void);
void os_cpu_occrate_calculation_process(void); 
void os_shell_cpu_occrate_counter_process(void); 
void os_stk_calculation_process(void);
void os_shell_run_time_counter_process(void); 
void os_shutdown_delaytime_set_ymdhms(os_u32 year,os_u8 mouth,os_u8 day,os_u8 hour,os_u8 minute,os_u8 second); 
os_u8 os_shell_compare_dig(char ch,char* p);
os_u32 os_shell_grab_dig(os_u8 n);
#endif
